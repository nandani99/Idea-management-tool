import IdeaManagementTool from './IdeaManagementTool';

const App = () => {
	

	return (
		<IdeaManagementTool/>
	);
};

export default App;