import { RiCloseCircleLine } from 'react-icons/ri';


const Idea = ({ id, text, date, handleDeleteNote,handleEditNote }) => {
	return (
		<div className='note'>
			<span>{text}</span>
			<div className='note-footer'>
				<RiCloseCircleLine
					onClick={() => handleDeleteNote(id)}
					className='delete-icon'
					size='1em'
				/>
			</div>
		</div>
	);
};

export default Idea;