import Idea from './Idea';
import AddIdea from './AddIdea';

const IdeasList = ({
	notes,
	handleAddNote,
	handleDeleteNote,
	handleEditNote
}) => {
	return (
		<div className='notes-list'>
			{notes.map((note) => (
				<Idea
					id={note.id}
					text={note.text}
					date={note.date}
					handleDeleteNote={handleDeleteNote}
					handleEditNote={handleEditNote}
				/>
			))}
			<AddIdea handleAddNote={handleAddNote} />
		</div>
	);
};

export default IdeasList;