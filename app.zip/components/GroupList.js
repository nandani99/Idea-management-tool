import Group from './Group';


const GroupList = ({
	groups,handleDeleteGroup,handleDeleteGroupNote
}) => {

	return (
		<div>
            <h1>Groups</h1>
			{groups.map((group) => (
				<Group
					group={group.group}
                    id={group.id}
                    handleDeleteGroup={handleDeleteGroup}
                    handleDeleteGroupNote={handleDeleteGroupNote}
				/>
                
			))}
			
		</div>
	);
};

export default GroupList;