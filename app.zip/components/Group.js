import { MdDeleteForever } from 'react-icons/md';
import GroupNote from './GroupNote';

const Group = ({ group,id,handleDeleteGroup,handleDeleteGroupNote }) => {
	return (
        <>
        <div className='group'>
        <h2 >
            Group {id} 
        
        <MdDeleteForever
					onClick={() => handleDeleteGroup(id)}
					className='delete-icon'
					size='1em'
				/>
        </h2>
        </div>
        <br/>
        <div className='notes-list'>
            {group.map((note) => (
				<GroupNote
                id={note.id}
                text={note.text}
                date={note.date}
                handleDeleteGroupNote={handleDeleteGroupNote}
                group_id={id}
				/>
			))}
        </div>
        <br/>
        </>
	);
};

export default Group;