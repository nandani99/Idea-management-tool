

const GroupNote = ({ id, text, date, handleDeleteGroupNote,group_id }) => {
	return (
		<div className='note'>
			<span>{text}</span>
			<div className='note-footer'>
				<small>{date}</small>
			</div>
		</div>
	);
};

export default GroupNote;